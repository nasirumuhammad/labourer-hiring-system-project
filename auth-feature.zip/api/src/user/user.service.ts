import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './entities/user.entity';
import { HashingService } from '@/common/services/hashing.service';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User) private readonly userRepository: Repository<User>,
    private readonly hashingService: HashingService,
  ) {}

  async findById(id: string): Promise<User | null> {
    return this.userRepository.findOneBy({ id });
  }

  /**
   * Includes the password hash — only use this for credential validation,
   * never return the result directly from a controller.
   */
  async findByEmailWithPassword(email: string): Promise<User | null> {
    return this.userRepository
      .createQueryBuilder('user')
      .addSelect('user.password')
      .where('user.email = :email', { email })
      .getOne();
  }

  async findByEmail(email: string): Promise<User | null> {
    return this.userRepository.findOneBy({ email });
  }

  async resetPassword(email: string, newPassword: string): Promise<void> {
    const hashedPassword = await this.hashingService.hash(newPassword);
    await this.userRepository.increment({ email }, 'tokenVersion', 1);
    await this.userRepository.update({ email }, { password: hashedPassword });
  }
}
