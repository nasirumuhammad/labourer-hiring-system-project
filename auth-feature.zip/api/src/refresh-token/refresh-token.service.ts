import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { EntityManager, Repository } from 'typeorm';
import { RefreshToken } from './entities/refresh-token.entity';

interface CreateRefreshTokenInput {
  userId: string;
  token: string;
  jti: string;
}

@Injectable()
export class RefreshTokenService {
  constructor(
    @InjectRepository(RefreshToken)
    private readonly refreshTokenRepository: Repository<RefreshToken>,
  ) {}

  async create(input: CreateRefreshTokenInput): Promise<RefreshToken> {
    const refreshToken = this.refreshTokenRepository.create(input);
    return this.refreshTokenRepository.save(refreshToken);
  }

  async createWithManager(
    manager: EntityManager,
    input: CreateRefreshTokenInput,
  ): Promise<RefreshToken> {
    const refreshToken = manager.create(RefreshToken, input);
    return manager.save(refreshToken);
  }

  async findByJti(jti: string): Promise<RefreshToken | null> {
    return this.refreshTokenRepository.findOneBy({ jti });
  }

  async deleteByIdWithManager(
    manager: EntityManager,
    id: string,
  ): Promise<void> {
    await manager.delete(RefreshToken, { id });
  }

  async deleteAllUserTokens(userId: string): Promise<void> {
    await this.refreshTokenRepository.delete({ userId });
  }
}
