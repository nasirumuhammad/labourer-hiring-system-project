import { Inject, Injectable } from '@nestjs/common';
import { ConfigType } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { randomUUID } from 'crypto';
import { jwtConfig } from '@/common/config/jwt.config';
import { User } from '@/user/entities/user.entity';
import { Payload, ResetPasswordPayload, TokenPair } from '@/types/payload.type';

@Injectable()
export class TokenService {
  constructor(
    private readonly jwtService: JwtService,
    @Inject(jwtConfig.KEY) private readonly jwt: ConfigType<typeof jwtConfig>,
  ) {}

  buildPayload(user: User): Payload {
    return {
      jti: randomUUID(),
      sub: user.id,
      tokenVersion: user.tokenVersion,
      role: user.role,
    };
  }

  generateAccessToken(payload: Payload): string {
    // Relies on JwtModule's registered default (access) secret/expiry.
    return this.jwtService.sign(payload);
  }

  generateRefreshToken(payload: Payload): string {
    return this.jwtService.sign(payload, this.jwt.refresh);
  }

  generateResetToken(user: User): string {
    const payload: ResetPasswordPayload = {
      sub: user.id,
      email: user.email,
    };
    return this.jwtService.sign(payload, this.jwt.reset);
  }

  verifyRefreshToken(token: string): Payload {
    return this.jwtService.verify<Payload>(token, {
      secret: this.jwt.refresh.secret,
    });
  }

  verifyResetToken(token: string): ResetPasswordPayload {
    return this.jwtService.verify<ResetPasswordPayload>(token, {
      secret: this.jwt.reset.secret,
    });
  }

  generateTokenPair(user: User): TokenPair {
    const payload = this.buildPayload(user);
    const accessToken = this.generateAccessToken(payload);
    const refreshToken = this.generateRefreshToken(payload);
    return {
      accessToken,
      refreshToken,
      payload,
    };
  }
}
